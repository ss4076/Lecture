package util;

import java.io.IOException;

public interface PushDispatcher {
    void sendNotification() throws IOException;
}

