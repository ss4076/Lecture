//
//  ViewController.swift
//  AsyncTest
//
//  Created by dong jun park on 2022/03/04.
//

import UIKit
import RxSwift
import RxCocoa
import WebKit

class ViewController: UIViewController {
    
//    private let hostUrlString = "http://test.whitehat.co.kr:9100/mobile/nft/list"
        private let hostUrlString = "https://test.whitehat.co.kr:9100/mobile/nft/list"
    
    private var webView: WKWebView!
    
    @IBOutlet weak var subView: UIView!
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    private var urlRequest: URLRequest!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // WebView web -> ios reg callback (사용 안함)
        let contentController = WKUserContentController()
        let config = WKWebViewConfiguration()
        config.preferences = WKPreferences()
        
        if #available(iOS 14.0, *) {
           config.defaultWebpagePreferences.allowsContentJavaScript = true
        } else {
           config.preferences.javaScriptEnabled = true
        }
        
        // web -> native 콜백 리스너 등록
        config.userContentController = contentController
        contentController.add(self, name: "callbackHandler")
        
        
        // WebView init and load
        webView = WKWebView(frame: .zero, configuration: config)
        
        self.subView.addSubview(webView)
        
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.leadingAnchor.constraint(equalTo: self.subView.leadingAnchor).isActive = true
        webView.trailingAnchor.constraint(equalTo: self.subView.trailingAnchor).isActive = true
        webView.topAnchor.constraint(equalTo: self.subView.topAnchor).isActive = true
        webView.bottomAnchor.constraint(equalTo: self.subView.bottomAnchor).isActive = true
        
        self.webView.endEditing(false)

        // 유저가 방문한 페이지 조회
        self.subView.sendSubviewToBack(webView)
        
        // 자바 스크립트의 alert 액션 처리
        webView.uiDelegate = self
        webView.navigationDelegate = self
        webView.allowsLinkPreview = false
        
        
        let nftServiceUrl = URL(string: hostUrlString)
        urlRequest = URLRequest(url: nftServiceUrl!)
        // progress 바 구현시 사용
        webView.addObserver(self, forKeyPath: #keyPath(WKWebView.estimatedProgress), options: .new, context: nil)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        loadWebView()
    }
    
    @IBAction func queryNftButtonAction(_ sender: Any) {
        
        loadWebView()
    }
    
    private func loadWebView() -> Void {
        
        activityIndicator.startAnimating()
        
        
        webView.load(urlRequest)
    }
    
    private func sendUserAgentInfo() -> Void {
    
        let jwt = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyYW9uMDAwMyIsImF1dGhvcml0aWVzIjoiUk9MRV9NRU1CRVIiLCJzeW1ib2wiOiJPQ1IiLCJ2ZXIiOiJ2MS4wIiwidHlwZSI6IkFQUCIsImp0dCI6IkFUIiwiZXhwIjoxNjU0Njc2NzMxLCJqdGkiOiIzTWZBbG00YjJwU1NWSmRGWXNBOCJ9.5rqKB2AdZLsOyMwDQA2YcYkABPAUKHoBYSAiT6TARP8"

        let refresh_jwt = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyYW9uMDAwMyIsImF1dGhvcml0aWVzIjoiUk9MRV9NRU1CRVIiLCJzeW1ib2wiOiJPQ1IiLCJ2ZXIiOiJ2MS4wIiwidHlwZSI6IkFQUCIsImp0dCI6IlJUIiwiZXhwIjoxNjU1MTk1MTMxLCJqdGkiOiJxWHlaMndIbDRoSnhOdFRab1NNMCJ9.Eo0fYXA0lDmFEtuVQclOGceAxc1zgOcY2RwK_F_uOyA"
        
//         javascript:sendTokenAndDid("eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyYW9uMDAwMyIsImF1dGhvcml0aWVzIjoiUk9MRV9NRU1CRVIiLCJzeW1ib2wiOiJPQ1IiLCJ2ZXIiOiJ2MS4wIiwidHlwZSI6IldFQiIsImp0dCI6IkFUIiwiZXhwIjoxNjU0Njc2NDAyLCJqdGkiOiJpY2JsbERJVjFuU1B4WVZWOG9RQiJ9.3IkZI5IMFlXoSO2_IAQ4N5_d9Gnk6vL17zdO28Xxvu","eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJyYW9uMDAwMyIsImF1dGhvcml0aWVzIjoiUk9MRV9NRU1CRVIiLCJzeW1ib2wiOiJPQ1IiLCJ2ZXIiOiJ2MS4wIiwidHlwZSI6IldFQiIsImp0dCI6IlJUIiwiZXhwIjoxNjU1MTk0ODAyLCJqdGkiOiJCWHRlUG1ldFlIM1dYblVaV1Z5aiJ9.NRYzAZh6g0EAv7J0-ZqaL0jH9vUmkxL4mDuqEdc4zs0", "raon0003")

        let did = "raon0003"
        let message = String(format:"sendTokenAndDid('%@','%@','%@')", jwt, refresh_jwt, did)
        print("ios -> web message: \(message)")
        
        DispatchQueue.main.async {
                
            self.webView.evaluateJavaScript(message, completionHandler: { result, error in

                if error != nil {
                    print("error: \(String(describing: error))")
                    return
                }
                
                if result != nil {
                   print("result: \(result!)")
                } else {
                   print("result is nil")
                }
            })
        }
    }
}

extension ViewController : WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
    
    // progress 바 구현시 사용
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        
//        print("observeValue keyPath: \(String(describing: keyPath))")
        // 0 ~ 1 값 (0: 로딩 시작, 1: 로딩완료)
//        print("wkWebView.estimatedProgress == \(Float((self.webView!.estimatedProgress)))")
    }
    
    func webView(_ webView: WKWebView, runJavaScriptAlertPanelWithMessage message: String, initiatedByFrame frame: WKFrameInfo, completionHandler: @escaping () -> Void) {
        
        print("runJavaScriptAlertPanelWithMessage message: \(message)")
        
        let alert = UIAlertController(title: "OmniOne!", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in
            print("ok handler: \(message)")
            completionHandler()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: {_ in
            print("cancel handler: \(message)")
            completionHandler()
        }))
        DispatchQueue.main.async {
            self.present(alert, animated: true)
            
        }
    }
        
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        
        print("webview didFinish")
        
        activityIndicator.stopAnimating()
        
        
            // 인증처리
        sendUserAgentInfo();
        
    }
    
    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
        
        print("webview didCommit")
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        
//        print("webview didStartProvisionalNavigation")
    }
    
    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        
        activityIndicator.stopAnimating()
        print("webview didFail")
    }
    
    func webView(_ webView: WKWebView, didReceiveServerRedirectForProvisionalNavigation navigation: WKNavigation!){
        
        print("webview redirect")
    }
    
    // url loding 요청(탐색) 호출
    func webView(_ webView: WKWebView,
                 decidePolicyFor navigationAction: WKNavigationAction,
                 decisionHandler: @escaping (WKNavigationActionPolicy) -> Void){
        
        print("webview callback")
        
        // http, http, html 아니면 탐색 x
        if let url = navigationAction.request.url, url.scheme != "http" && url.scheme != "https", !url.absoluteString.hasSuffix("html") {
            
            print("url: \(String(describing: navigationAction.request.url))")
            print("url.scheme: \(String(describing: url.scheme))")
            
            decisionHandler(.cancel)
        }
        // 프로토콜이 http, https일때만 url탐색 허용
        else {
            print("allow request")
            decisionHandler(.allow)

        }
    }
    
    func webViewDidClose(_ webView: WKWebView) {
        
        webView.removeFromSuperview()
    }
    
    // web -> native 콜백 리스너
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {

        print("userContentController callback \(message.name)")
        if message.name == "callbackHandler" {
            print(message.body)
        }
    }
}

